from rest_framework import viewsets
from .models import VendorProductMapping
from .serializers import VendorProductMappingSerializer

class VendorProductMappingViewSet(viewsets.ModelViewSet):
    # Sirf wahi mappings dikhayega jo Active hain
    queryset = VendorProductMapping.objects.filter(is_active=True)
    serializer_class = VendorProductMappingSerializer